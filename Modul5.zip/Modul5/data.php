<html>
<head><title>Data Mahsiswa</title></head>
<?php
$conn = mysqli_connect('localhost', 'root', '', 'informtika');

?>
<body>
	<center>
	<h3>Masukkan Data Mahasiswa:</h3>
	<table>
	<form method='POST' action=''>
	<tr>
		<td>Nama</td>
		<td>:</td>
		<td><input type='text' name='nama' id='nama'></td>
	</tr>
	<tr>
		<td>NIM</td>
		<td>:</td>
		<td><input type='text' name='nim' id='nim'></td>
	</tr>
	<tr>
		<td>Kelas</td>
		<td>:</td>
		<td><input type='radio' name='kelas' value='A' checked>
		A
		<input type='radio' name='kelas' value='B' checked>
		B
		<input type='radio' name='kelas' value='C' checked>
		C</td>
	</tr>
	<tr>
		<td>Alamat</td>
		<td>:</td>
		<td><input type='text' name='alamat'</td>
	</tr> 
	</table>
		<input type='submit' value='Masukkan' name='submit'>
	</form>
	<?php
		error_reporting(E_ALL ^ E_NOTICE);
		$nim =$_POST['nim'];
		$nama = $_POST['nama'];
		$kelas = $_POST['kelas'];
		$alamat = $_POST['alamat'];
		$submit = $_POST['submit'];
		$input = "insert into mahasiswa (nim, nama, kelas, alamat) values ('$nim','$nama','$kelas','$alamat')";
		if ($submit){
			if($nim==''){
				echo "</br>NIM tidak boleh kosong, diisi dulu";
				}elseif($nama==''){
				echo "</br>Nama tidak boleh kosong, diisi dulu";
				}elseif($alamat==''){
				echo "</br>Alamat tidak boleh kosong, diisi dulu";
				}else{
				mysql_query($input);
				echo'</br>Data Berhasil Dimasukkan';
			}
		}
	?>
	<hr>
	<h3>Data Mahasiswa</h3>
	<table border='1' width='50%'>
	<tr>
		<td align='center'><b>NIM</b></td>
		<td align='center'><b><Nama></b></td>
		<td align='center'><b>Alamat</b></td>
	</tr>
	<?php
		$cari="select * from mahasiswa order by nim";
		$hasil=mysqli_query($conn, $cari);
		while($data=mysqli_fetch_row($hasil)){
			echo"
			<tr>
				<td>$data[0]</td>
				<td>$data[1]</td>
				<td>$data[2]</td>
				<td>$data[3]</td>
			</tr>";
		}
	?>
	</table>
	</center>
	</body>
	</html>
	
	

